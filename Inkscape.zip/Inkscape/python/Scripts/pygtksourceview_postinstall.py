# -*- coding: utf-8 -*-


import sys


if len(sys.argv) == 2:
    if sys.argv[1] == "-install":
        print ('pygtksourceview is now installed on your machine.')
